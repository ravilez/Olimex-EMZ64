include("${CMAKE_CURRENT_LIST_DIR}/rule.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/file.cmake")

set(Olimex_uart_default_library_list )

# Handle files with suffix s, for group default-XC32
if(Olimex_uart_default_default_XC32_FILE_TYPE_assemble)
add_library(Olimex_uart_default_default_XC32_assemble OBJECT ${Olimex_uart_default_default_XC32_FILE_TYPE_assemble})
    Olimex_uart_default_default_XC32_assemble_rule(Olimex_uart_default_default_XC32_assemble)
    list(APPEND Olimex_uart_default_library_list "$<TARGET_OBJECTS:Olimex_uart_default_default_XC32_assemble>")

endif()

# Handle files with suffix S, for group default-XC32
if(Olimex_uart_default_default_XC32_FILE_TYPE_assembleWithPreprocess)
add_library(Olimex_uart_default_default_XC32_assembleWithPreprocess OBJECT ${Olimex_uart_default_default_XC32_FILE_TYPE_assembleWithPreprocess})
    Olimex_uart_default_default_XC32_assembleWithPreprocess_rule(Olimex_uart_default_default_XC32_assembleWithPreprocess)
    list(APPEND Olimex_uart_default_library_list "$<TARGET_OBJECTS:Olimex_uart_default_default_XC32_assembleWithPreprocess>")

endif()

# Handle files with suffix [cC], for group default-XC32
if(Olimex_uart_default_default_XC32_FILE_TYPE_compile)
add_library(Olimex_uart_default_default_XC32_compile OBJECT ${Olimex_uart_default_default_XC32_FILE_TYPE_compile})
    Olimex_uart_default_default_XC32_compile_rule(Olimex_uart_default_default_XC32_compile)
    list(APPEND Olimex_uart_default_library_list "$<TARGET_OBJECTS:Olimex_uart_default_default_XC32_compile>")

endif()

# Handle files with suffix cpp, for group default-XC32
if(Olimex_uart_default_default_XC32_FILE_TYPE_compile_cpp)
add_library(Olimex_uart_default_default_XC32_compile_cpp OBJECT ${Olimex_uart_default_default_XC32_FILE_TYPE_compile_cpp})
    Olimex_uart_default_default_XC32_compile_cpp_rule(Olimex_uart_default_default_XC32_compile_cpp)
    list(APPEND Olimex_uart_default_library_list "$<TARGET_OBJECTS:Olimex_uart_default_default_XC32_compile_cpp>")

endif()

# Handle files with suffix [cC], for group default-XC32
if(Olimex_uart_default_default_XC32_FILE_TYPE_dependentObject)
add_library(Olimex_uart_default_default_XC32_dependentObject OBJECT ${Olimex_uart_default_default_XC32_FILE_TYPE_dependentObject})
    Olimex_uart_default_default_XC32_dependentObject_rule(Olimex_uart_default_default_XC32_dependentObject)
    list(APPEND Olimex_uart_default_library_list "$<TARGET_OBJECTS:Olimex_uart_default_default_XC32_dependentObject>")

endif()


# Main target for this project
add_executable(Olimex_uart_default_image_UP7s0Hl4 ${Olimex_uart_default_library_list})

set_target_properties(Olimex_uart_default_image_UP7s0Hl4 PROPERTIES
    OUTPUT_NAME "default"
    SUFFIX ".elf"
    RUNTIME_OUTPUT_DIRECTORY "${Olimex_uart_default_output_dir}")
target_link_libraries(Olimex_uart_default_image_UP7s0Hl4 PRIVATE ${Olimex_uart_default_default_XC32_FILE_TYPE_link})
# Add the link options from the rule file.
Olimex_uart_default_link_rule( Olimex_uart_default_image_UP7s0Hl4)

# Add bin2hex target for converting built file to a .hex file.
string(REGEX REPLACE [.]elf$ .hex Olimex_uart_default_image_name_hex ${Olimex_uart_default_image_name})
add_custom_target(Olimex_uart_default_Bin2Hex ALL
    COMMAND ${MP_BIN2HEX} \"${Olimex_uart_default_output_dir}/${Olimex_uart_default_image_name}\"
    BYPRODUCTS ${Olimex_uart_default_output_dir}/${Olimex_uart_default_image_name_hex}
    COMMENT "Convert built file to .hex")
add_dependencies(Olimex_uart_default_Bin2Hex Olimex_uart_default_image_UP7s0Hl4)




