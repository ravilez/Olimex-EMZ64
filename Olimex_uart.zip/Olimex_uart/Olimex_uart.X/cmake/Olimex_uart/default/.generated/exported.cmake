set(DEPENDENT_MP_BIN2HEXOlimex_uart_default_UP7s0Hl4 "c:/Program Files/Microchip/xc32/v5.10/bin/xc32-bin2hex.exe")
set(DEPENDENT_DEPENDENT_TARGET_ELFOlimex_uart_default_UP7s0Hl4 ${CMAKE_CURRENT_LIST_DIR}/../../../../out/Olimex_uart/default.elf)
set(DEPENDENT_TARGET_DIROlimex_uart_default_UP7s0Hl4 ${CMAKE_CURRENT_LIST_DIR}/../../../../out/Olimex_uart)
set(DEPENDENT_BYPRODUCTSOlimex_uart_default_UP7s0Hl4 ${DEPENDENT_TARGET_DIROlimex_uart_default_UP7s0Hl4}/${sourceFileNameOlimex_uart_default_UP7s0Hl4}.c)
add_custom_command(
    OUTPUT ${DEPENDENT_TARGET_DIROlimex_uart_default_UP7s0Hl4}/${sourceFileNameOlimex_uart_default_UP7s0Hl4}.c
    COMMAND ${DEPENDENT_MP_BIN2HEXOlimex_uart_default_UP7s0Hl4} --image ${DEPENDENT_DEPENDENT_TARGET_ELFOlimex_uart_default_UP7s0Hl4} --image-generated-c ${sourceFileNameOlimex_uart_default_UP7s0Hl4}.c --image-generated-h ${sourceFileNameOlimex_uart_default_UP7s0Hl4}.h --image-copy-mode ${modeOlimex_uart_default_UP7s0Hl4} --image-offset ${addressOlimex_uart_default_UP7s0Hl4} 
    WORKING_DIRECTORY ${DEPENDENT_TARGET_DIROlimex_uart_default_UP7s0Hl4}
    DEPENDS ${DEPENDENT_DEPENDENT_TARGET_ELFOlimex_uart_default_UP7s0Hl4})
add_custom_target(
    dependent_produced_source_artifactOlimex_uart_default_UP7s0Hl4 
    DEPENDS ${DEPENDENT_TARGET_DIROlimex_uart_default_UP7s0Hl4}/${sourceFileNameOlimex_uart_default_UP7s0Hl4}.c
    )
