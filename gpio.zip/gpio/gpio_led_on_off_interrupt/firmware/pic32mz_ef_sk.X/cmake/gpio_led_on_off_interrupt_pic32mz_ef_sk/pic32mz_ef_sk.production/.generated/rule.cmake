# The following functions contains all the flags passed to the different build stages.

set(PACK_REPO_PATH "C:/Users/richa/.mchp_packs" CACHE PATH "Path to the root of a pack repository.")

function(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_assemble_rule target)
    set(options
        "-g"
        "${ASSEMBLER_PRE}"
        "-mprocessor=32MZ2048EFH064"
        "-Wa,--defsym=__MPLAB_BUILD=1${MP_EXTRA_AS_POST},--defsym=__MPLAB_DEBUGGER_PK4=1,-I${CMAKE_CURRENT_SOURCE_DIR}/../../.."
        "-mdfp=${PACK_REPO_PATH}/Microchip/PIC32MZ-EF_DFP/1.5.173")
    list(REMOVE_ITEM options "")
    target_compile_options(${target} PRIVATE "${options}")
    target_include_directories(${target} PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../..")
endfunction()
function(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_assembleWithPreprocess_rule target)
    set(options
        "-x"
        "assembler-with-cpp"
        "-g"
        "${MP_EXTRA_AS_PRE}"
        "-mdfp=${PACK_REPO_PATH}/Microchip/PIC32MZ-EF_DFP/1.5.173"
        "-mprocessor=32MZ2048EFH064"
        "-Wa,--defsym=__MPLAB_BUILD=1${MP_EXTRA_AS_POST},-I${CMAKE_CURRENT_SOURCE_DIR}/../../..")
    list(REMOVE_ITEM options "")
    target_compile_options(${target} PRIVATE "${options}")
    target_compile_definitions(${target} PRIVATE "XPRJ_pic32mz_ef_sk=pic32mz_ef_sk")
    target_include_directories(${target} PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../..")
endfunction()
function(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_compile_rule target)
    set(options
        "-g"
        "${CC_PRE}"
        "-x"
        "c"
        "-c"
        "-mprocessor=32MZ2048EFH064"
        "-ffunction-sections"
        "-O1"
        "-Wformat=2"
        "-Werror-implicit-function-declaration"
        "-Wfloat-equal"
        "-Wundef"
        "-Wshadow"
        "-Wpointer-arith"
        "-Wbad-function-cast"
        "-Wwrite-strings"
        "-Waggregate-return"
        "-Wstrict-prototypes"
        "-Wmissing-format-attribute"
        "-Wno-deprecated-declarations"
        "-Wpacked"
        "-Wredundant-decls"
        "-Wnested-externs"
        "-Winline"
        "-Wlong-long"
        "-Wunreachable-code"
        "-Wmissing-noreturn"
        "-mdfp=${PACK_REPO_PATH}/Microchip/PIC32MZ-EF_DFP/1.5.173")
    list(REMOVE_ITEM options "")
    target_compile_options(${target} PRIVATE "${options}")
    target_compile_definitions(${target}
        PRIVATE "__MPLAB_DEBUGGER_PK4=1"
        PRIVATE "XPRJ_pic32mz_ef_sk=pic32mz_ef_sk")
    target_include_directories(${target}
        PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src"
        PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk"
        PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../..")
endfunction()
function(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_compile_cpp_rule target)
    set(options
        "-g"
        "${CC_PRE}"
        "-mprocessor=32MZ2048EFH064"
        "-frtti"
        "-fexceptions"
        "-fno-check-new"
        "-fenforce-eh-specs"
        "-ffunction-sections"
        "-O1"
        "-fno-common"
        "-Wformat=2"
        "-Werror-implicit-function-declaration"
        "-Wfloat-equal"
        "-Wundef"
        "-Wshadow"
        "-Wpointer-arith"
        "-Wbad-function-cast"
        "-Wwrite-strings"
        "-Waggregate-return"
        "-Wstrict-prototypes"
        "-Wmissing-format-attribute"
        "-Wno-deprecated-declarations"
        "-Wpacked"
        "-Wredundant-decls"
        "-Wnested-externs"
        "-Winline"
        "-Wlong-long"
        "-Wunreachable-code"
        "-Wmissing-noreturn"
        "-mdfp=${PACK_REPO_PATH}/Microchip/PIC32MZ-EF_DFP/1.5.173")
    list(REMOVE_ITEM options "")
    target_compile_options(${target} PRIVATE "${options}")
    target_compile_definitions(${target} PRIVATE "XPRJ_pic32mz_ef_sk=pic32mz_ef_sk")
    target_include_directories(${target}
        PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src"
        PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk"
        PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/../../..")
endfunction()
function(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_dependentObject_rule target)
    set(options
        "-mprocessor=32MZ2048EFH064"
        "-mdfp=${PACK_REPO_PATH}/Microchip/PIC32MZ-EF_DFP/1.5.173")
    list(REMOVE_ITEM options "")
    target_compile_options(${target} PRIVATE "${options}")
endfunction()
function(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_link_rule target)
    set(options
        "-g"
        "${MP_EXTRA_LD_PRE}"
        "-mprocessor=32MZ2048EFH064"
        "-Wl,--defsym=__MPLAB_BUILD=1${MP_EXTRA_LD_POST},--script=${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_LINKER_SCRIPT},--defsym=_min_heap_size=512,--gc-sections,--no-code-in-dinit,--no-dinit-in-serial-mem,-L${CMAKE_CURRENT_SOURCE_DIR}/../../..,-Map=mem.map,--memorysummary,memoryfile.xml"
        "-mdfp=${PACK_REPO_PATH}/Microchip/PIC32MZ-EF_DFP/1.5.173")
    list(REMOVE_ITEM options "")
    target_link_options(${target} PRIVATE "${options}")
    target_compile_definitions(${target} PRIVATE "XPRJ_pic32mz_ef_sk=pic32mz_ef_sk")
endfunction()
