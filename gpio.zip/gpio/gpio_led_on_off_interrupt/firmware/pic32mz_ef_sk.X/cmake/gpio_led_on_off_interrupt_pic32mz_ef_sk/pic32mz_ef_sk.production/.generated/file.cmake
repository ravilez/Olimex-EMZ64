# The following variables contains the files used by the different stages of the build process.
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_assemble)
set_source_files_properties(${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_assemble} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_assemble})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_assembleWithPreprocess)
set_source_files_properties(${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_assembleWithPreprocess} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_assembleWithPreprocess})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_compile
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/exceptions.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/initialization.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/interrupts.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/peripheral/clk/plib_clk.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/peripheral/evic/plib_evic.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/peripheral/gpio/plib_gpio.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/stdio/xc32_monitor.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/main.c")
set_source_files_properties(${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_compile} PROPERTIES LANGUAGE C)
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_compile_cpp)
set_source_files_properties(${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_compile_cpp} PROPERTIES LANGUAGE CXX)
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_pic32mz_ef_sk_XC32_FILE_TYPE_link)

# The linker script used for the build.
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_LINKER_SCRIPT "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/pic32mz_ef_sk/p32MZ2048EFH064.ld")
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_image_name "pic32mz_ef_sk-production.elf")
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_image_base_name "pic32mz_ef_sk-production")

# The output directory of the final image.
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_output_dir "${CMAKE_CURRENT_SOURCE_DIR}/../../../out/gpio_led_on_off_interrupt_pic32mz_ef_sk/production")

# The full path to the final image.
set(gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_full_path_to_image ${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_output_dir}/${gpio_led_on_off_interrupt_pic32mz_ef_sk_pic32mz_ef_sk_image_name})
