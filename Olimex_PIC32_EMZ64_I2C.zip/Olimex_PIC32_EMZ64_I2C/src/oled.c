/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "config/default/peripheral/i2c/master/plib_i2c5_master.h"
#include "config/default/peripheral/gpio/plib_gpio.h"
#include "oled.h"
#include "font.h"

#define SYS_CLK_FREQ 200000000UL

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */
/** Descriptive Data Item Name

  @Summary
    Brief one-line summary of the data item.
    
  @Description
    Full description, explaining the purpose and usage of data item.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
  @Remarks
    Any additional remarks
 */

static uint8_t screenBuffer[OLED_SIZE+1];
static uint8_t *oledBuffer = &screenBuffer[1];

void delay_us(uint32_t us)
{
    uint32_t start = _CP0_GET_COUNT();
    uint32_t ticks = us * (SYS_CLK_FREQ / 2 / 1000000); // Count increments at SYSCLK/2

    while ((_CP0_GET_COUNT() - start) < ticks);
}

void delay_ms(uint32_t ms)
{
    delay_us(ms * 1000);
}

/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */

/** 
  @Function
    int ExampleLocalFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Description
    Full description, explaining the purpose and usage of the function.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

  @Precondition
    List and describe any required preconditions. If there are no preconditions,
    enter "None."

  @Parameters
    @param param1 Describe the first parameter to the function.
    
    @param param2 Describe the second parameter to the function.

  @Returns
    List (if feasible) and describe the return values of the function.
    <ul>
      <li>1   Indicates an error occurred
      <li>0   Indicates an error did not occur
    </ul>

  @Remarks
    Describe any special behavior not described above.
    <p>
    Any additional remarks.

  @Example
    @code
    if(ExampleFunctionName(1, 2) == 0)
    {
        return 3;
    }
 */
static int ExampleLocalFunction(int param1, int param2) {
    return 0;
}

static void OledWaitBus() {
    
    while(I2C5_IsBusy());
}

static void _i2cWrite(uint8_t *data, uint32_t size)
{
    
    OledWaitBus();
    I2C5_Write(OLED_ADDRESS, data, size);
}

static void _set_display_on_off(bool state) {
    uint8_t command[2] = { 0x00, 0xae | (uint8_t)state };
    _i2cWrite(command, sizeof(command));
}

static void _set_multiplex_ratio(uint8_t ratio) {
    uint8_t command[3] = { 0x00, 0xa8, ratio };
    _i2cWrite(command, sizeof(command));
}

static void _set_display_offset(uint8_t offset)
{
    uint8_t command[3] = { 0x00, 0xd3, offset };
    _i2cWrite(command, sizeof(command));
}

static void _set_display_start_line(uint8_t line)
{
    uint8_t command[2] = { 0x00, 0x40 | line };
    _i2cWrite(command, sizeof(command));
}

static void _set_segment_remap(uint8_t remap)
{
    uint8_t command[2] = { 0x00, 0xa0 | remap };
    _i2cWrite(command, sizeof(command));
}

static void _set_com_scan_direction(uint8_t dir)
{
    uint8_t command[2] = { 0x00, 0xc0 | dir << 3 };
    _i2cWrite(command, sizeof(command));
}

static void _set_com_pins_configuration(uint8_t conf, uint8_t remap)
{
    uint8_t command[3] = { 0x00, 0xda, 0x02 | (conf << 4) | (remap << 5) };
    _i2cWrite(command, sizeof(command));
}

static void _set_contrast_control(uint8_t contrast)
{
    uint8_t command[3] = { 0x00, 0x81, contrast };
    _i2cWrite(command, sizeof(command));
}


static void _entire_display_on(uint8_t status)
{
    uint8_t command[2] = { 0x00, 0xa4 | status };
    _i2cWrite(command, sizeof(command));
}

static void _set_inverse_display(uint8_t inverse)
{
    uint8_t command[2] = { 0x00, 0xa6 | inverse };
    _i2cWrite(command, sizeof(command));
}

static void _set_display_clock(uint8_t divider, uint8_t freq)
{
    uint8_t command[3] = { 0x00, 0xd5, (freq << 4 | divider) };
    _i2cWrite(command, sizeof(command));
}

static void _charge_pump_settings(uint8_t on)
{
    uint8_t command[3] = { 0x00, 0x8d, 0x10 | (on << 2) };
    _i2cWrite(command, sizeof(command));
}

static void _set_memory_addressing_mode(uint8_t mode) {
    uint8_t command[3] = { 0x00, 0x20, mode };
    _i2cWrite(command, sizeof(command));
}

static void _set_column_address(uint8_t start, uint8_t end)
{
    uint8_t command[4] = { 0x00, 0x21, start, end };
    _i2cWrite(command, sizeof(command));
}

static void _set_page_address(uint8_t start, uint8_t end)
{
    uint8_t command[4] = { 0x00, 0x22, start, end };
    _i2cWrite(command, sizeof(command));
}

static inline _swap(uint8_t *a, uint8_t *b) {
    uint8_t x;
    x = *a;
    *a = *b;
    *b = x;
}

/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    int ExampleInterfaceFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Remarks
    Refer to the example_file.h interface header for function usage details.
 */
void oledInitialize(void)
{    
    //BSP_LCDTurnOn();
    LCD_ON_OFF_Set();
    /* Send initialization */
    delay_ms(10);                       // Power-on stabilization

    _set_display_on_off(false);
    delay_ms(1);                        // Recommended
    _set_multiplex_ratio(63);
    delay_ms(1);                        // Recommended
    _set_display_offset(0);
    delay_ms(1);                        // Recommended
    _set_display_start_line(0);
    delay_ms(1);                        // Recommended
    
    _set_segment_remap(1);
    delay_ms(1);                        // Recommended
        
    _set_com_pins_configuration(1, 0);
    delay_ms(1);                        // Recommended
    _set_com_scan_direction(1);
    delay_ms(1);                        // Recommended
    
    
    _set_contrast_control(0x7f);
    delay_ms(1);                        // Recommended
    _entire_display_on(0);
    delay_ms(1);                        // Recommended
    _set_inverse_display(0);
    delay_ms(1);                        // Recommended
    _set_display_clock(0, 15);
    delay_ms(1);                        // Recommended
    _charge_pump_settings(1);
    delay_ms(1);                        // Recommended
    _set_display_on_off(true);
    delay_ms(1);                        // Recommended
    
    _set_memory_addressing_mode(0);
    delay_ms(1);                        // Recommended
    _set_column_address(0, 127);
    delay_ms(1);                        // Recommended
    _set_page_address(0, 7);
    delay_ms(1);                        // Recommended

    /* Clear display */
    oledClear();
    oledUpdate();
}

void oledUpdate(void)
{
    screenBuffer[0] = 0x40;
    _i2cWrite(screenBuffer, OLED_SIZE+1);
}


void oledClear(void)
{
    memset(oledBuffer, 0, OLED_SIZE);
}

void oledDrawPixel(uint8_t x, uint8_t y, bool colour)
{
/*    if(x < WIDTH && y < HEIGHT) {
        uint8_t page = y/8;
        uint8_t bit = y%8;
        uint16_t index = (page * WIDTH) + x;
              
        if (colour)
            oledBuffer[index] |= (1<<bit);
        else
            oledBuffer[index] &= ~(1<<bit);
    }
*/
    if(y < 0 || y >= HEIGHT || x < 0 || x >= WIDTH)
        return;
    if (colour)
        oledBuffer[y/8 * 128 + x] |= 1 << (y % 8);
    else
        oledBuffer[y/8 * 128 + x] &= ~(1 << (y % 8));
}


void oledDrawVLine(uint8_t x)
{
    uint8_t i;
    
    if (x >= WIDTH) return;

    for(i = 0; i < HEIGHT; i++) {
        oledDrawPixel(x, i, true);
    }
}

void oledDrawHLine(uint8_t y)
{
    uint8_t i;
    if (y >= HEIGHT) return;
    
    for(i = 0; i < WIDTH; i++) {
        oledDrawPixel(i, y, true);
    }
}

void oledDrawPixelChar(uint8_t Row, uint8_t Column, uint8_t Color)
{
    if(Row < 0 || Row >= HEIGHT || Column < 0 || Column >= WIDTH)
        return;
#if 0
    if (Color)
        oledBuffer[Row/8 * 128 + Column] |= 1 << (Row % 8);
    else
        oledBuffer[Row/8 * 128 + Column] &= ~(1 << (Row % 8));
#else   // same idea but using bitwise operations (they are faster)
    if (Color)
        oledBuffer[((Row>>3)<<7) + Column] |= 1 << (Row & 7);
    else
        oledBuffer[((Row>>3)<<7) + Column] &= ~(1 << (Row & 7));
#endif
    return;
}

// works only if the Row is divided by 8
void oledDrawPixelChar2(uint8_t Row, uint8_t Column, uint8_t Data)
{
    if(Row < 0 || Row >= HEIGHT || Column < 0 || Column >= WIDTH)
        return;
    oledBuffer[((Row>>3)<<7) + Column] = Data;
    return;
}

void oledClearRow (uint8_t Row, uint8_t Inverse)
{
    uint8_t i;
    if (Inverse)
        for (i=0; i<128; i++)
            oledDrawPixelChar2 (Row<<3, i, 0xFF);
    else
        for (i=0; i<128; i++)
            oledDrawPixelChar2 (Row<<3, i, 0);
}

void oledDrawChar (uint8_t StartRow, uint8_t StartColumn, uint8_t C, uint8_t Inverse)
{
    unsigned char Row, Column, Temp;
    for (Column=0; Column<6; Column++)
    {
        if (Column==5)
            Temp = 0;
        else
            Temp = font_6x8 [C-32][Column];
        if (Inverse)
            Temp = ~Temp;
        for (Row=0; Row<8; Row++)
            oledDrawPixelChar(StartRow+Row, StartColumn+Column, Temp & (1<<Row));
            //oledDrawPixelChar2(StartRow+Row, StartColumn+Column, Temp);
    }       
    return;
}

void oledDrawString (uint8_t x, uint8_t y, uint8_t C[], uint8_t Inverse)
{
    int i;
    for (i=0; C[i]; i++)
        oledDrawChar (x, y+i*6, C[i], Inverse);
    return;
}

/* *****************************************************************************
 End of File
 */
