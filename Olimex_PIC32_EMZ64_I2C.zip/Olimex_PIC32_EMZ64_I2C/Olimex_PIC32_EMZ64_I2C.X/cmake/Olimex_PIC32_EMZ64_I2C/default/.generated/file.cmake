# The following variables contains the files used by the different stages of the build process.
set(Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_assemble)
set_source_files_properties(${Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_assemble} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_assemble})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_assembleWithPreprocess)
set_source_files_properties(${Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_assembleWithPreprocess} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_assembleWithPreprocess})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_compile
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/exceptions.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/initialization.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/interrupts.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/peripheral/clk/plib_clk.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/peripheral/evic/plib_evic.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/peripheral/gpio/plib_gpio.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/peripheral/i2c/master/plib_i2c5_master.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/peripheral/i2c/plib_i2c_smbus_common.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/stdio/xc32_monitor.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/main.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/oled.c")
set_source_files_properties(${Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_compile} PROPERTIES LANGUAGE C)
set(Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_compile_cpp)
set_source_files_properties(${Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_compile_cpp} PROPERTIES LANGUAGE CXX)
set(Olimex_PIC32_EMZ64_I2C_default_default_XC32_FILE_TYPE_link)

# The linker script used for the build.
set(Olimex_PIC32_EMZ64_I2C_default_LINKER_SCRIPT "${CMAKE_CURRENT_SOURCE_DIR}/../../../../src/config/default/p32MZ2048EFH064.ld")
set(Olimex_PIC32_EMZ64_I2C_default_image_name "default.elf")
set(Olimex_PIC32_EMZ64_I2C_default_image_base_name "default")

# The output directory of the final image.
set(Olimex_PIC32_EMZ64_I2C_default_output_dir "${CMAKE_CURRENT_SOURCE_DIR}/../../../out/Olimex_PIC32_EMZ64_I2C")

# The full path to the final image.
set(Olimex_PIC32_EMZ64_I2C_default_full_path_to_image ${Olimex_PIC32_EMZ64_I2C_default_output_dir}/${Olimex_PIC32_EMZ64_I2C_default_image_name})
