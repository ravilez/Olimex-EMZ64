set(DEPENDENT_MP_BIN2HEXOlimex_PIC32_EMZ64_I2C_default_vtu_68lB "c:/Program Files/Microchip/xc32/v5.10/bin/xc32-bin2hex.exe")
set(DEPENDENT_DEPENDENT_TARGET_ELFOlimex_PIC32_EMZ64_I2C_default_vtu_68lB ${CMAKE_CURRENT_LIST_DIR}/../../../../out/Olimex_PIC32_EMZ64_I2C/default.elf)
set(DEPENDENT_TARGET_DIROlimex_PIC32_EMZ64_I2C_default_vtu_68lB ${CMAKE_CURRENT_LIST_DIR}/../../../../out/Olimex_PIC32_EMZ64_I2C)
set(DEPENDENT_BYPRODUCTSOlimex_PIC32_EMZ64_I2C_default_vtu_68lB ${DEPENDENT_TARGET_DIROlimex_PIC32_EMZ64_I2C_default_vtu_68lB}/${sourceFileNameOlimex_PIC32_EMZ64_I2C_default_vtu_68lB}.c)
add_custom_command(
    OUTPUT ${DEPENDENT_TARGET_DIROlimex_PIC32_EMZ64_I2C_default_vtu_68lB}/${sourceFileNameOlimex_PIC32_EMZ64_I2C_default_vtu_68lB}.c
    COMMAND ${DEPENDENT_MP_BIN2HEXOlimex_PIC32_EMZ64_I2C_default_vtu_68lB} --image ${DEPENDENT_DEPENDENT_TARGET_ELFOlimex_PIC32_EMZ64_I2C_default_vtu_68lB} --image-generated-c ${sourceFileNameOlimex_PIC32_EMZ64_I2C_default_vtu_68lB}.c --image-generated-h ${sourceFileNameOlimex_PIC32_EMZ64_I2C_default_vtu_68lB}.h --image-copy-mode ${modeOlimex_PIC32_EMZ64_I2C_default_vtu_68lB} --image-offset ${addressOlimex_PIC32_EMZ64_I2C_default_vtu_68lB} 
    WORKING_DIRECTORY ${DEPENDENT_TARGET_DIROlimex_PIC32_EMZ64_I2C_default_vtu_68lB}
    DEPENDS ${DEPENDENT_DEPENDENT_TARGET_ELFOlimex_PIC32_EMZ64_I2C_default_vtu_68lB})
add_custom_target(
    dependent_produced_source_artifactOlimex_PIC32_EMZ64_I2C_default_vtu_68lB 
    DEPENDS ${DEPENDENT_TARGET_DIROlimex_PIC32_EMZ64_I2C_default_vtu_68lB}/${sourceFileNameOlimex_PIC32_EMZ64_I2C_default_vtu_68lB}.c
    )
